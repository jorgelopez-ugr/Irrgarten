package irrgarten;

import java.util.ArrayList;

public class FuzzyPlayer extends Player {

    public FuzzyPlayer(Player otro) {
        
        super(otro);
    }
    //aunque hagas la asignacion al momento de resucitar nunca se llega a llamar a este
    //move, siempre se sigue llamando al move del player, luego podemos considerar
    //que la asignacion que habiamos realizado no es correcta
    
    @Override
    public Directions move (Directions direction , ArrayList<Directions> validMoves){

        Directions output;
            boolean contained = validMoves.contains(direction);
            if (contained && validMoves.size()>0){
                output = Dice.nextStep(direction, validMoves, getIntelligence());
            }
            else
            {
                validMoves.remove(direction);
                output = Dice.nextStep(validMoves.get(0), validMoves, getIntelligence());
            }
            return output;
    }
    
    //no puede overridear con una proteccion mas restrictiva que la del padre
    @Override
    public float attack(){
        return super.sumWeapons() + Dice.intensity(super.getStrength());
    }
    //no le pones override porque como en el padre es privado pues no ibas a poder accederlo de otra forma
    protected float defensiveEnergy(){
        return super.sumShields() + Dice.intensity(super.getIntelligence());
    }
    
    public String toString(){
        String txt = " FUZZZZZZY PLAYER ";
        txt += super.toString();
        return txt;
    }
}