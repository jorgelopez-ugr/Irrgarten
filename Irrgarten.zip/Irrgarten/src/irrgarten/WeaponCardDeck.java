package irrgarten;

public class WeaponCardDeck extends CardDeck<Weapon> {
    protected void addCards(){
        for (int i = 0 ; i < 5 ; i++){
            Weapon nueva = new Weapon(Dice.weaponPower() , Dice.usesLeft());
            super.addCard(nueva);
        }
    }
}
