package irrgarten;

import java.util.ArrayList;

public class Player extends LabyrinthCharacter{
    
    private static final int MAX_WEAPONS = 2;
    private static final int MAX_SHIELDS = 3;
    private static final int INITIAL_HEALTH = 10;
    private static final int HITS2LOSE = 3;
    private char number;
    private int consecutiveHits = 0;
    
    private ArrayList<Weapon> weapons = new ArrayList<>();
    private ArrayList<Shield> shields = new ArrayList<>();

    WeaponCardDeck weaponsDeck = new WeaponCardDeck();
    ShieldCardDeck shieldsDeck = new ShieldCardDeck();
    
    public Player(char number, float intelligence, float strength) {
        super("JUGADOR " + number ,intelligence, strength, INITIAL_HEALTH);
        this.number = number;
    }
    
    public Player(Player otro){
        super(otro);
        this.number = otro.number;
    }
    
//    @Override
//    public Player clone() throws CloneNotSupportedException{
//        Player nuevo = (Player) super.clone();
//        
//        ArrayList<Weapon> wClon = new ArrayList<>();
//        ArrayList<Shield> sClon = new ArrayList<>();
//        
//        for (Weapon element : weapons){
//            wClon.add( (Weapon)element.clone() );
//        }
//        
//        for (Shield elemetn : shields){
//            sClon.add( (Shield)elemetn.clone() );
//        }
//        
//        nuevo.weapons = wClon;
//        nuevo.shields = sClon;
//        
//        return nuevo;
//    }

    public char getNumber() {
        return number;
    }
    
    public void resurrect(){
        consecutiveHits = 0;
        weapons.clear();
        shields.clear();
        super.setHealth(INITIAL_HEALTH);
    }
    
    public float attack(){
        return super.getStrength() + sumWeapons();
    }
    
    public boolean defend(float receivedAttack){
        return manageHit(receivedAttack);
    }
    
    public String toString(){
        String txt = super.toString();
        txt += weapons.toString()+"\n";
        txt += shields.toString()+"\n";
        
        return txt;
    }
    
    public Weapon newWeapon(){
        Weapon nueva = new Weapon(Dice.weaponPower() , Dice.usesLeft());
        return nueva;
    }
    
    public Shield newShield(){
        Shield nueva = new Shield(Dice.shieldPower() , Dice.usesLeft());
        return nueva;
    }
    
    private float defensiveEnergy(){
        return super.getIntelligence() + sumShields();
    }
    
    public void resetHits(){
        consecutiveHits = 0;
    }
    
    public void incConsecutiveHits(){
        consecutiveHits++;
    }
    
    public float sumWeapons(){
        float total_attack = 0;
        
        for (int i = 0 ; i < weapons.size() ; i++){
            total_attack += weapons.get(i).attack();
        }
        
        return total_attack;
    }
    
    public float sumShields(){
        float total_defend = 0;
        
        for (int i = 0 ; i < shields.size() ; i++){
            total_defend += shields.get(i).defend();
        }
        
        return total_defend;
    }
    
    public boolean manageHit(float receivedAttack){
        float defense = defensiveEnergy();
        
        if (defense < receivedAttack){
            gotWounded();
            incConsecutiveHits();
        }
        else{
            resetHits();
        }
        
        boolean lose;
        
        if (consecutiveHits == HITS2LOSE || dead()){
        
            resetHits();
            lose = true;
        }
        else{
            lose = false;
        }
        
        return lose;
    }
    
    public Directions move(Directions direction ,ArrayList<Directions> validMoves){
        int size = validMoves.size();
        
        boolean contained = validMoves.contains(direction);
        
        if (size > 0 && !contained){
            return validMoves.get(0);
        }
        else{
            return direction;
        }
    }
    
    public void receiveReward(){
        int wReward = Dice.weaponsReward();
        int sReward = Dice.shieldsReward();
        
        for (int i = 1 ; i <= wReward ; i++){
//            Weapon wnew = newWeapon();
            Weapon wnew = weaponsDeck.nextCard();
            receiveWeapon(wnew);
        }
        
        for (int i = 1 ; i <= sReward ; i++){
//            Shield snew = newShield();
            Shield snew = shieldsDeck.nextCard();
            receiveShield(snew);
        }
        
        int extraHealth = Dice.healthReward();
        super.setHealth(super.getHealth() + extraHealth);
    }
    
    public void receiveWeapon(Weapon w){
        for (int i = 0 ; i < weapons.size() ; i++){
            Weapon wi = weapons.get(i);
            boolean discard = wi.discard();
            
            if (discard){
                weapons.remove(wi);
            }
        }
        
        int size = weapons.size();
        
        if (size < MAX_WEAPONS){
            weapons.add(w);
        }
    }
    
    public void receiveShield(Shield s){
        for (int i = 0 ; i < shields.size() ; i++){
            Shield si = shields.get(i);
            boolean discard = si.discard();
            
            if (discard){
                shields.remove(si);
            }
        }
        
        int size = shields.size();
        
        if (size < MAX_SHIELDS){
            shields.add(s);
        }
    }
}