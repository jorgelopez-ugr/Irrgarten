
package irrgarten;

enum Orientation{
    VERTICAL,
    HORIZONTAl
}
