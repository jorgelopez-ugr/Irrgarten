
package irrgarten;

public class TestP1 {
    public static void main(String[] args) {
        Weapon arma = new Weapon(10,2);
        Shield escudo = new Shield(10 , 2);
        
        System.out.println(arma.toString());
        System.out.println(escudo.toString());
        
        System.out.println("ATACANDO CON EL ARMA Y DEFENDIENDO HASTA AGOTAR LOS USOS PARA MOSTRAR OTRA VEZ");

        arma.attack();
        arma.attack();
        
        escudo.defend();
        escudo.defend();
        
        System.out.println(arma.toString());
        System.out.println(escudo.toString());
        
        Weapon arma2 = new Weapon(10,2);
        Shield escudo2 = new Shield(10 , 2);
        
        System.out.println("PROBANDO A DESCARTAR");
        
        System.out.println(arma2.toString());
        System.out.println(escudo2.toString());
        
        arma2.discard();
        escudo2.discard();
        
        System.out.println(arma2.toString());
        System.out.println(escudo2.toString());
        
        arma2.attack();
        escudo2.defend();
        
        arma2.discard();
        escudo2.discard();
        
        System.out.println(arma2.toString());
        System.out.println(escudo2.toString());
    }
}
