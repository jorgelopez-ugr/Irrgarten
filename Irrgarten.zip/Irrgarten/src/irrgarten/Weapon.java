package irrgarten;

public class Weapon extends CombatElement{
    //constructor
    
    public Weapon(float power, int uses){
        super(power,uses);
    }
    
    //metodos de la clase
    
    public float attack(){
        return super.produceEffect();
    }
    
    public boolean discard(){
        return super.discard();
    }
    
    public CombatElement clone(){
        CombatElement nuevo = new Weapon(super.getEffect(),super.getUses());
        return nuevo;
    }
    
    //mostrar
    
    @Override
    public String toString(){
        String txt =  "Sword stats: ";
        txt += super.toString();
        return txt;
    }
}
