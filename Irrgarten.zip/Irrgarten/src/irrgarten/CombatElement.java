package irrgarten;

public abstract class CombatElement {
    private float effect;
    private int uses;

    public CombatElement(float effect, int uses) {
        this.effect = effect;
        this.uses = uses;
    }
    
    protected float produceEffect(){
        if (uses > 0){
            uses--;
            return effect;
        }
        else{
            return (float)0;
        }
    }
    
    public boolean discard(){
        if (Dice.discardElement(uses)){
            return true;
        }
        else{
            return false;
        }
    }
    
    public String toString(){
        String txt = "Effect: " + effect + " Uses Left: " + uses;
        return txt;
    }

    public float getEffect() {
        return effect;
    }

    public int getUses() {
        return uses;
    }
    
    
}
