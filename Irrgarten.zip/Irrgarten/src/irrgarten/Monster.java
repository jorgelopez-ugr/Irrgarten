
package irrgarten;

public class Monster extends LabyrinthCharacter {
    private static final int INITIAL_HEALTH = 50;

    //constructor
    public Monster(String name, float intelligence, float strength) {
        super(name, intelligence, strength, INITIAL_HEALTH);
    }
    
    public float attack(){
        return Dice.intensity(super.getStrength());
    }
    
    public String toString(){
        String txt = super.toString();
        return txt;
    }
    
    //pendiente de acabar
    public boolean defend(float receivedAttack){
        boolean isDead = dead();
        
        if (!isDead){
            float defensiveEnergy = Dice.intensity(super.getIntelligence());
            
            if (defensiveEnergy < receivedAttack){
                gotWounded();
                isDead = dead();
            }
        }
        
        return isDead;
    }
}
