
package irrgarten;

import java.util.Random;
import java.util.ArrayList;

public class Dice {
    private static int MAX_USES = 5;
    private static float MAX_INTELLIGENCE = (float)10.0;
    private static float MAX_STRENGTH = (float)10.0;
    private static float RESURRECT_PROB = (float)0.3;
    private static int WEAPONS_REWARD = 2;
    private static int SHIELDS_REWARD = 3;
    private static int HEALTH_REWARD = 5;
    private static int MAX_ATTACK = 3;
    private static int MAX_SHIELD = 2;
    private static float MONSTER_PROB = (float)0.15;
    
    private static Random generator = new Random();
    
    public static int randomPos(int max){
        return generator.nextInt(max);
    }
    
    public static int whoStarts(int nplayers){
        return generator.nextInt(nplayers);
    }
    
    public static float randomIntelligence(){
        return generator.nextFloat() * MAX_INTELLIGENCE;
    }
    
    public static float randomStrength(){
        return generator.nextFloat() * MAX_STRENGTH;
    }
    
    public static boolean resurrectPlayer(){
        return generator.nextFloat() <= RESURRECT_PROB;
    }
    
    public static int weaponsReward(){
        return generator.nextInt(WEAPONS_REWARD+1);
    }
    
    public static int shieldsReward(){
        return generator.nextInt(SHIELDS_REWARD+1);
    }
    
    public static int healthReward(){
        return generator.nextInt(HEALTH_REWARD+1);
    }
    
    public static float weaponPower(){
        return generator.nextFloat() * MAX_ATTACK;
    }
    
    public static float shieldPower(){
        return generator.nextFloat() * MAX_SHIELD;
    }
    
    public static int usesLeft(){
        return generator.nextInt(MAX_USES);
    }
    
    public static float intensity(float competence){
        return generator.nextFloat() * competence;
    }
    
    public static boolean discardElement(int usesLeft){
//        return generator.nextFloat() >= usesLeft/MAX_USES;
        return generator.nextFloat() < usesLeft/MAX_USES;
    } 
    
    public static boolean addElement(){
        return generator.nextFloat() <= (float)0.15;
    }
    
    public static boolean bool(){
        return generator.nextBoolean();
    }
    
    public static Directions nextStep(Directions preference, ArrayList<Directions> validMoves, float intelligence){
        float probabilidad = generator.nextFloat() * intelligence;
        
        if (probabilidad > 0.5){
            return preference;
        }
        else{
            return validMoves.get(randomPos(validMoves.size()));
        }
    }
    
    public static Directions randomDir(ArrayList<Directions> validMoves){
        int randomMove = randomPos(validMoves.size());
        return validMoves.get(randomMove);
    }
}
