//EL PROBLEMA DE LA DUPLICACION: NI CALVO NI CON 3 PELUCAS
//    - Es cierto que es importante que hagamos new cuando creamos
//un objeto pero para realizar copia de un objeto ya creado no es necesario
//
//    - Como yo hacia new para una copia estaba generando un player nuevo copia
//que quedaba inerte en la posicion porque se reservaba como para uno mas
//
//    - Solucion no abusar del new, usarlo solo para crear objetos nuevos no 
//para los que ya estan creados dado que esto causara que se cree uno nuevo

package irrgarten;

import java.util.ArrayList;

public class Game {
    private final int MAX_ROUNDS = 10;
    private int currentPlayerIndex;
    private String log;
    
    private final float STATS_MONSTER = (float)50;
    private final float STATS_PLAYER = (float)1;
    
    private Player currentPlayer;
    
    private ArrayList<Player> players;
    private ArrayList<Monster> monsters;
    
    private Labyrinth laberinto;
    
//    private boolean isFuzzy = false;
    
    public Game(){
        //de momento el numero de players va a ser 1 obligado
        players = new ArrayList<>();
        monsters = new ArrayList<>();
        configureLabyrinth();
        
        //int num_jugadores = Dice.randomPos(10);
        
        
        //por comodidad lo voy a dejar en 1 player para la parte del debug
        int num_jugadores = 1;
        for (int i = 0 ; i < num_jugadores ; i++){
            Player jugador = new Player((char)(i+'0'),STATS_PLAYER,STATS_PLAYER);
            players.add(jugador);
        }
        laberinto.spreadPlayers(players);
        currentPlayerIndex = Dice.randomPos(num_jugadores);
        currentPlayer = players.get(currentPlayerIndex);
    }
    
    //MODIFICACION QUE PERMITIRA SELECCIONAR EL NUMERO DE JUGADORES
    
    public Game(int num_jugadores){
        
        if (num_jugadores <= 0){
            num_jugadores = 1;
        }
        
        players = new ArrayList<>();
        monsters = new ArrayList<>();
        configureLabyrinth();
        
        for (int i = 0 ; i < num_jugadores ; i++){
            Player jugador = new Player((char)(i+'0'),STATS_PLAYER,STATS_PLAYER);
            players.add(jugador);
        }
        
        laberinto.spreadPlayers(players);
        currentPlayerIndex = Dice.randomPos(num_jugadores);
        currentPlayer = players.get(currentPlayerIndex);
    }
    
    public boolean finished(){
        return laberinto.haveAWinner();
    }
    
    public GameState getGameState(){
        GameState estado = new GameState(laberinto.toString(), players.toString(),
                                          monsters.toString(), currentPlayerIndex,
                                          finished(), log);
        
        return estado;
    }
    
    public void configureLabyrinth(){        
        laberinto = new Labyrinth(10, 10, Dice.randomPos(10), Dice.randomPos(10)); 
        
        int num_monsters = Dice.randomPos(4)+1;
//        int num_monsters = 5;
        for (int i = 0 ; i < num_monsters ; i++){
            Monster monstruo = new Monster("*MONSTER " + i, STATS_MONSTER, STATS_MONSTER);
            monsters.add(monstruo);
            laberinto.addMonster(Dice.randomPos(10), Dice.randomPos(10), monsters.get(i));
        
        }   
        
        for (int i = 0 ; i < 10 ; i++){
            
            int[] pos = new int[2];
            pos = laberinto.randomEmptyPos();
            
            laberinto.addBlock(Orientation.HORIZONTAl,pos[0],pos[1],1);
        }
    }
    
    public void nextPlayer(){
        currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
        currentPlayer = players.get(currentPlayerIndex);
    }
    
    public void logPlayerWon(){
        log += "ha ganado el PLAYER: " + currentPlayerIndex;
        log += "\n";
    }
    
    public void logMonsterWon(){
        log += "ha ganado el MONSTER";
        log += "\n";
    }
    
    public void logResurrected(){
        log += "ha resucitado el PLAYER COMO UN FUZZY PLAYER" + currentPlayerIndex;
        log += "\n";
    }
    
    public void logPlayerSkipTurn(){
        log += "se ha skipeado el turno del PLAYER: " + currentPlayerIndex;
        log += "\n";
    }
    
    public void logPlayerNoOrders(){
        log += "no fue posible seguir las instrucciones del jugador humano";
        log += "\n";
    }
    
    public void logNoMonster(){
        log += "jugador o se ha movido a una celda vacia o no le fue posible moverse";
        log += "\n";
    }
    
    public void logRounds(int rounds, int max){
        log += "llevamos de momento " + rounds + " rondas del total de posibles: " + max;
        log += "\n";
    }
    
    public Directions actualDirection(Directions preferedDirection){
        int currentRow = currentPlayer.getRow();
        int currentCol = currentPlayer.getCol();
        
        ArrayList <Directions> valid_Moves = new ArrayList<>();
        valid_Moves = laberinto.validMoves(currentRow,currentCol);
        
        //en algunos momentos deberia ir al move de player y en otros al de fuzzy
        //pero eso dependera del tipo que tenga currentPlayer
        Directions output = currentPlayer.move(preferedDirection, valid_Moves);
            
        return output;
    }
    
    public GameCharacter combat(Monster monster){
        GameCharacter winner = GameCharacter.PLAYER;
        int rounds = 0;
        
        float playerAttack = currentPlayer.attack();
        boolean lose = monster.defend(playerAttack);
        
        while (!lose && rounds < MAX_ROUNDS){
            
            winner = GameCharacter.MONSTER;
            rounds++;
            
            float monsterAttack = monster.attack();
            lose = currentPlayer.defend(monsterAttack);

            if (!lose){
                playerAttack = currentPlayer.attack();
                winner = GameCharacter.PLAYER;
                lose = monster.defend(playerAttack);
            }
        }
             
        logRounds(rounds, MAX_ROUNDS);
        
        return winner;
    }
    
    public void manageResurrection(){
        boolean resurrect = Dice.resurrectPlayer();
//        boolean resurrect = true;
        if (resurrect){
            currentPlayer.resurrect();
            FuzzyPlayer nuevo = new FuzzyPlayer(currentPlayer);
//            currentPlayer = nuevo;
            this.players.set(this.currentPlayerIndex, nuevo);
            logResurrected();
        }
        else{
            logPlayerSkipTurn();
        }
    }
    
    public void manageReward(GameCharacter winner){
        if (winner == GameCharacter.PLAYER){
            currentPlayer.receiveReward();
            logPlayerWon();
        }
        else{
            logMonsterWon();
        }
    }
    
    //actualDirection aun no esta definido
    //putPlayer no esta definido aun
    public boolean nextStep(Directions preferredDirection){
        log = "";
        boolean dead = currentPlayer.dead();
        
        if (!dead){
            Directions direction = actualDirection(preferredDirection);
            
            if (direction != preferredDirection){
                logPlayerNoOrders();
            }
            
            Monster monster = laberinto.putPlayer(direction,currentPlayer);
            
            if (monster == null){
                logNoMonster();
            }
            else{
                GameCharacter winner = combat(monster);
                manageReward(winner);
            }
        }
        else{
            manageResurrection();
        }
        
        boolean endGame = finished();
                
        if (!endGame){
            nextPlayer();
        }
        
        return endGame;
    }
    
    
}
