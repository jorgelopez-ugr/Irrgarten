package irrgarten;

public class ShieldCardDeck extends CardDeck<Shield>{
    protected void addCards(){
        for (int i = 0 ; i < 5 ; i++){
            Shield nueva = new Shield(Dice.shieldPower(), Dice.usesLeft());
            super.addCard(nueva);
        }
    }
}
