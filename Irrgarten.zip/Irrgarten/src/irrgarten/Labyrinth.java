
package irrgarten;

import java.util.ArrayList;

public class Labyrinth {
    static private final char BLOCK_CHAR= (char) 1;
    static private final char EMPTY_CHAR= '.';
    static private final char MONSTER_CHAR= 'M';
    static private final char COMBAT_CHAR= 'C';
    static private final char EXIT_CHAR= 'E';
    static private final int ROW=0;
    static private final int COL=1;
    
    private int nRow;
    private int nCol;
    private int exitRow;
    private int exitCol;
    
//    asi se podria hacer con arraylist pero por simpleza voy a usar una matriz normal
//    private ArrayList<ArrayList<Monster>> matrizMonstruos = new ArrayList<>();
    
    static private Monster[][] matrizMonsters;
    static private Player[][] matrizPlayers;
    static private char[][] laberinto;

    //si quisieramos tener un modo debug se insertaria aqui por ejemplo con una condicion
    
    public Labyrinth(int nRow, int nCol, int exitRow, int exitCol) {
        this.nRow = nRow;
        this.nCol = nCol;
        this.exitRow = exitRow;
        this.exitCol = exitCol;
        
        //RECUERDA QUE HAY QUE INICIALIZARLO TODO EN JAVA
        
        laberinto = new char[nRow][nCol];
        matrizMonsters = new Monster[nRow][nCol];
        matrizPlayers = new Player[nRow][nCol];
        
        
        for (int i = 0 ; i < nRow ; i++){
            for (int j = 0 ; j < nCol ; j++){
                if (posOK(i, j)){
                    laberinto[i][j] = EMPTY_CHAR;
                    matrizMonsters[i][j] = null;
                    matrizPlayers[i][j] = null;
                }
            }
        }
        
        if (posOK(exitRow, exitCol)){
            laberinto[exitRow][exitCol] = EXIT_CHAR;
        }
    }
    
    public Player get(int row, int col){
        return matrizPlayers[row][col];
    }
    
    public boolean haveAWinner(){
        if (laberinto[exitRow][exitCol] != EXIT_CHAR){
            return true;
        }
        else{
            return false;
        }
    }
    
    public String toString(){
        String visualiza = "";
        
        for(int i=0; i<nRow; i++){
            visualiza += " # ";
            for(int j = 0; j<nCol; j++){                
                visualiza += laberinto[i][j] + "  ";
                
            }
            visualiza += " # ";
            visualiza += "\n\n";
        }
        
        return visualiza;
    }
    
    public void addMonster(int row, int col, Monster monstruo){
        
        //meter comprobacion de que los enteros row y col son validos
        if (laberinto[row][col] == EMPTY_CHAR && posOK(row, col)){
            matrizMonsters[row][col] = monstruo;
            laberinto[row][col] = MONSTER_CHAR;
        
            monstruo.setPos(row, col);
        }
    }
    
    public boolean posOK(int row , int col){
        if (row >= 0 && col >= 0 && row < nRow && col < nCol ){
            return true;
        }
        else{
            return false;
        }
    }
    
    public boolean emptyPos(int row , int col){
        if (posOK(row, col)){
            if (laberinto[row][col] == EMPTY_CHAR){
                return true;
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }
    
    public boolean monsterPos(int row, int col){
        if (posOK(row, col)){
            if (laberinto[row][col] == MONSTER_CHAR){
                return true;
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }
    
    public boolean exitPos(int row, int col){
        if (posOK(row, col)){
            if (laberinto[row][col] == EXIT_CHAR){
                return true;
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }
    
    public boolean combatPos(int row, int col){
        if (posOK(row, col)){
            if (laberinto[row][col] == COMBAT_CHAR){
                return true;
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }
    
    public boolean canStepOn(int row, int col){
        
        if (posOK(row, col)){
            if (emptyPos(row, col) || monsterPos(row, col) || exitPos(row, col)){
                return true;
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }
    
    public void updateOldPos(int row , int col){
        if (posOK(row, col)){
            if (combatPos(row, col)) {
                laberinto[row][col] = MONSTER_CHAR;
            }
            else{
                laberinto[row][col] = EMPTY_CHAR;
            }
        }
    }
    
    public int[] dir2pos(int row, int col, Directions direccion){
        
        int[] posResult = new int [2];
        posResult[ROW] = row;
        posResult[COL] = col;
        
        if (direccion == Directions.DOWN){
            posResult[ROW]++;
        }
        else if (direccion == Directions.UP){
            posResult[ROW]--;
        }
        else if (direccion == Directions.LEFT){
            posResult[COL]--;
        }
        else if (direccion == Directions.RIGHT){
            posResult[COL]++;
        }
        
        return posResult;
    }
    
    int[] randomEmptyPos(){
//        int[] randomEmpty = {Dice.randomPos(nRow), Dice.randomPos(nCol)};
        //atento a la declaracion de este tipo de array, lo de arriba no es correcto
        //porque no estamos reservando para nada
        
        int[] randomEmpty = new int[2];
        randomEmpty[ROW] = Dice.randomPos(nRow);
        randomEmpty[COL] = Dice.randomPos(nCol);
        
        while (!emptyPos(randomEmpty[ROW], randomEmpty[COL])){
            randomEmpty[ROW] = Dice.randomPos(nRow);
            randomEmpty[COL] = Dice.randomPos(nCol);
        }
        
        return randomEmpty;
    }
    
    public void addBlock(Orientation orientation, int startRow, int startCol,int length){
        int incRow = 0;
        int incCol = 0;
        
        if (orientation == Orientation.VERTICAL){
            incRow = 1;
        }
        else{
            incCol = 1;
        }
        
        int row = startRow;
        int col = startCol;
        
        while(posOK(row, col) && emptyPos(row, col) && length > 0 ){
            laberinto[row][col] = BLOCK_CHAR;
            
            length--;
            row += incRow;
            col += incCol;
        }
    }
    
    //falta terminar el putPlayer2D
    
    //lo que falla aqui es lo que te entra en la primera vez
    public Monster putPlayer(Directions direction,Player player){
        int oldRow = player.getRow();
        int oldCol = player.getCol();
        
        int[] newPos = new int[2];
        newPos = dir2pos(oldRow, oldCol, direction);
        Monster monster = putPlayer2D(oldRow, oldCol, newPos[ROW], newPos[COL], player);

        return monster;
    }
  
    public Monster putPlayer2D(int oldRow, int oldCol, int row, int col , Player player){
        Monster output = null;
        
        if (canStepOn(row,col)){
            if (posOK(oldRow,oldCol)){
                Player p = matrizPlayers[oldRow][oldCol];
                
                if (p == player){
                    updateOldPos(oldRow, oldCol);
                    matrizPlayers[oldRow][oldCol] = null;
                }
            }
            
            boolean monsterPos = monsterPos(row, col);
            
            if (monsterPos){
                laberinto[row][col] = COMBAT_CHAR;
                output = matrizMonsters[row][col];
            }
            else{
                char number = player.getNumber();
                laberinto[row][col] = number;
            }
            
            matrizPlayers[row][col] = player;
            player.setPos(row, col);
        }
        
        return output;
    }
    
    public void spreadPlayers(ArrayList<Player> players){
        for (int i = 0 ; i < players.size() ; i++){
            Player p = players.get(i);
            
            int[] pos = new int[2];
            pos = randomEmptyPos();
            
            putPlayer2D(-1, -1, pos[ROW], pos[COL], p);
        }
    }
    
    public ArrayList<Directions> validMoves(int row, int col){
        ArrayList<Directions> output = new ArrayList<>();
        
        if (canStepOn(row+1, col)){
            output.add(Directions.DOWN);
        }
        
        if (canStepOn(row-1, col)){
            output.add(Directions.UP);
        }
        
        if (canStepOn(row, col+1)){
            output.add(Directions.RIGHT);
        }
        
        if (canStepOn(row, col-1)){
            output.add(Directions.LEFT);
        }
        
        return output;
    }
}
