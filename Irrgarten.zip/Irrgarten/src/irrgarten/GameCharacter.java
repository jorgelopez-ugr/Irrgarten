
package irrgarten;

enum GameCharacter {
    PLAYER,
    MONSTER
}