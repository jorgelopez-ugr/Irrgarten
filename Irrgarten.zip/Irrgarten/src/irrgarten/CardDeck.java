package irrgarten;

import java.util.ArrayList;
import java.util.Collections;

public abstract class CardDeck <T> {
    private ArrayList <T> cardDeck;
    
    public CardDeck(){
        cardDeck = new ArrayList<>();
    }
    
    protected abstract void addCards();
    
    protected void addCard(T card){
        cardDeck.add(card);
    }
    
    public T nextCard(){
        if (cardDeck.size() == 0){
            addCards();
            Collections.shuffle(cardDeck);
        }
        
        T card = cardDeck.get(0);
        cardDeck.remove(card);
        
        return card;
    }
}
