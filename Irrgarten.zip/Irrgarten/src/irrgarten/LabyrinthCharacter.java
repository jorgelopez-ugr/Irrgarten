package irrgarten;

public abstract class LabyrinthCharacter {
    
    private String name;
    private float intelligence;
    private float strength;
    private float health;
    private int row;
    private int col;

    public LabyrinthCharacter(String name,float intelligence, float strength, float health) {
        this.name = name;
        this.intelligence = intelligence;
        this.strength = strength;
        this.health = health;
    }
    
    public LabyrinthCharacter(LabyrinthCharacter otro){
        this.name = otro.name;
        this.intelligence = otro.intelligence;
        this.strength = otro.strength;
        this.health = otro.health;
        this.row = otro.row;
        this.col = otro.col;
    }
    
    public boolean dead(){
        return health <= 0;
    }

    protected float getIntelligence() {
        return intelligence;
    }

    protected float getStrength() {
        return strength;
    }

    protected float getHealth() {
        return health;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }
    
    public void setPos(int row, int col){
        this.row = row;
        this.col = col;
    }

    public void setHealth(float health) {
        this.health = health;
    }
    
    public String toString(){
        String txt ="\nNombre: "+ name + "\n(" + "Inteligencia:  " + intelligence + " ,Fuerza:  " + strength + " ,Salud: " + health;
        txt += "\n Posicion:["+ row +"] ["+ col+ "] ) \n";
        
        return txt;
    }
    
    protected void gotWounded(){
        health--;
    }
    
    public abstract float attack();
    public abstract boolean defend(float receivedAttack);
}
