package irrgarten;

public class Shield extends CombatElement {
    //constructor
    
    public Shield(float protection , int uses) {
        super(protection,uses);
    }
    
    //metodos de la clase
    
    public float defend(){
        return super.produceEffect();
    }
    
    public boolean discard(){
        return super.discard();
    }
    
    public CombatElement clone(){
        CombatElement nuevo = new Shield(super.getEffect(),super.getUses());
        return nuevo;
    }
    
    //mostrar
    
    @Override
    public String toString(){
        String txt = "Shield stats: ";
        txt += super.toString();
        return txt;
    }
    
}
