package Main;

import UI.Graficos;
import UI.TextUI;
import UI.UI;
import controller.Controller;
import irrgarten.Game;
import UI.Logs;

public class Main {
    public static void main(String[] args) {
    
            while (true){
                Graficos vista = new Graficos();
//        TextUI vista = new TextUI();
            
                int tWaiting = 0;
                while (!vista.canStart()){
                    tWaiting++;
                
                    if (tWaiting == 100)
                        System.err.println("espera respuesta del usuario");
                }
            
                int num_players = vista.getNumPlayers();
        
                Game partida = new Game(num_players);

                Controller controlador = new Controller(partida,vista);
                
                controlador.play();
                
                while (!vista.canStart()){
                    tWaiting++;
                
                    if (tWaiting == 100)
                        System.err.println("espera que se pulse restart");
                    
                }
            }
    }
}
